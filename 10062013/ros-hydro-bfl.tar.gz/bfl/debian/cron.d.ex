#
# Regular cron jobs for the orocos-bfl package
#
0 4	* * *	root	orocos-bfl_maintenance
