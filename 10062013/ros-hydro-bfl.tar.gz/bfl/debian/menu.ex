?package(orocos-bfl):needs="X11|text|vc|wm" section="Apps/see-menu-manual"\
  title="orocos-bfl" command="/usr/bin/orocos-bfl"
