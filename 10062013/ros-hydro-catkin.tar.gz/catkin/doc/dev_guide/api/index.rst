Catkin Python API
=================

Contents:

.. toctree::
   :maxdepth: 2

   catkin

Scripts used by cmake macros:

.. toctree::
   :maxdepth: 2

   interrogate_setup_dot_py
   parse_package_xml
   python_version


Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

