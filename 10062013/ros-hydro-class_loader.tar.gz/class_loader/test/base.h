#ifndef BASE_H
#define BASE_H

class Base
{
  public:
    virtual void saySomething() = 0;
};

#endif
