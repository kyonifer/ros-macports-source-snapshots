^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package cmake_modules
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.0 (2013-07-24)
------------------
* Initial release, includes the FindTinyXML.cmake CMake module
