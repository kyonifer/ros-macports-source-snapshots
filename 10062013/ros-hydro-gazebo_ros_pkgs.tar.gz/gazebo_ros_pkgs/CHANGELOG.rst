^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package gazebo_ros_pkgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.3.2 (2013-09-19)
------------------

2.3.1 (2013-08-27)
------------------

2.3.0 (2013-08-12)
------------------
* Renamed ros_control_plugin, updated documentation

2.2.1 (2013-07-29)
------------------

2.2.0 (2013-07-29)
------------------

2.1.5 (2013-07-18)
------------------

2.1.4 (2013-07-14)
------------------

2.1.3 (2013-07-13)
------------------

2.1.2 (2013-07-12)
------------------
* 2.1.1

2.1.1 (2013-07-10 19:11)
------------------------

2.1.0 (2013-06-27)
------------------
* Added args to launch files, documentation
* Updated package.xml

2.0.2 (2013-06-20)
------------------

2.0.1 (2013-06-19)
------------------
* Incremented version to 2.0.1
* Updated documentation diagrams

2.0.0 (2013-06-18)
------------------
* Changed version to 2.0.0 based on gazebo_simulator being 1.0.0
* Updated package.xml files for ros.org documentation purposes
* Created new diagram
* Moved diagrams into repository
* Renamed meta package for gazebo_ros_pkgs
