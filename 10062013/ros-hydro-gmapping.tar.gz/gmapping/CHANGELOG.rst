^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package gmapping
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.3.0 (2013-06-28 17:51:57 -0700)
---------------------------------
- Catkinized in preparation of Hydro release
- The gmapping SLAM implementation has been moved out into a separate repo: https://github.com/ros-perception/openslam_gmapping
