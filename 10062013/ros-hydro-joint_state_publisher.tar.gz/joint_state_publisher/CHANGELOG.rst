^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package joint_state_publisher
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.10.15 (2013-08-17)
--------------------

* joint_state_publisher: do not install script to global bin
  Also clean up no longer required setup.py
