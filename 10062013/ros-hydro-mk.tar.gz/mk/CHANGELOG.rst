^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package mk
^^^^^^^^^^^^^^^^^^^^^^^^

1.10.7 (2013-10-04)
-------------------

1.10.6 (2013-08-22)
-------------------

1.10.5 (2013-08-21)
-------------------

1.10.4 (2013-07-05)
-------------------
* update eclipse-project target to not try to delete CATKIN_IGNORE marker files and check before trying to delete other files/folders (`#20 <https://github.com/ros/ros/issues/20>`_)

1.10.3 (2013-07-03)
-------------------

1.10.2 (2013-06-18)
-------------------

1.10.1 (2013-06-06)
-------------------
* add missing environment exports to make eclipse-projects of dry packages build
* cleanup catkin generated files/directories after make eclips-project

1.10.0 (2013-03-22 09:23)
-------------------------

1.9 (Groovy)
============

1.9.44 (2013-03-13)
-------------------

1.9.43 (2013-03-08)
-------------------

1.9.42 (2013-01-25)
-------------------

1.9.41 (2013-01-24)
-------------------
* modified install location of download_checkmd5 script to work in devel space and be consistent with other files

1.9.40 (2013-01-13)
-------------------

1.9.39 (2012-12-30)
-------------------
* first public release for Groovy
