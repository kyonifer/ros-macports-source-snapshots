^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package navfn
^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.11.4 (2013-09-27)
-------------------
* Package URL Updates
* fixed `#103 <https://github.com/ros-planning/navigation/issues/103>`_, navfn_node not installed
* Potential missing dependency
