pcl_conversions
===============

This package provides conversions from PCL data types and ROS message types.


Code & tickets
--------------

.. Build status: |Build Status|

.. .. |Build Status| image:: https://secure.travis-ci.org/ros-perception/pcl_conversions.png
   :target: http://travis-ci.org/ros-perception/pcl_conversions

+-----------------+------------------------------------------------------------+
| pcl_conversions | http://ros.org/wiki/pcl_conversions                        |
+-----------------+------------------------------------------------------------+
| Issues          | http://github.com/ros-perception/pcl_conversions/issues    |
+-----------------+------------------------------------------------------------+
.. | Documentation   | http://ros-perception.github.com/pcl_conversions/doc       |
.. +-----------------+------------------------------------------------------------+

