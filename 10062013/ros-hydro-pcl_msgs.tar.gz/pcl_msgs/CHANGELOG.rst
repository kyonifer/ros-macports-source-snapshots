^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pcl_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.0 (2013-07-09)
------------------
* Generate messages into the pcl_msgs namespace rather than the pcl namespace

0.0.3 (2012-12-15)
------------------
* fix deps for messages
* Updated for new <buildtool_depend>catkin<...> rule

0.0.2 (2012-11-26 18:50)
------------------------
* increasing version
* ros message generation prefix hack

0.0.1 (2012-11-26 17:48)
------------------------
* initial commit - pcl ROS messages
