random_numbers
==============

This library contains wrappers for generating floating point values, integers, quaternions using boost libraries.
