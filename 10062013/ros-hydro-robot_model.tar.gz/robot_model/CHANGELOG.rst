^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package robot_model
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.10.15 (2013-08-17)
--------------------
* remove unneeded deps (fix `#32 <https://github.com/ros/robot_model/issues/32>`_)
* Created new diagram for documenting URDF
