rosconsole_bridge
=================

Pipes console_bridge output to rosconsole/rosout when console_bridge is used in a ROS-dependent package
