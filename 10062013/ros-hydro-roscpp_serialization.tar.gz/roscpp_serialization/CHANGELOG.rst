^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package roscpp_serialization
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.16 (2013-07-14)
-------------------
* fix alignment in serialization on ARM (`#14 <https://github.com/ros/roscpp_core/issues/14>`_)

0.3.15 (2013-06-06)
-------------------
* fix compiler warning about unused variable (`#11 <https://github.com/ros/roscpp_core/issues/11>`_)
* fix install destination for dll's under Windows

0.3.14 (2013-03-21)
-------------------

0.3.13 (2013-03-08)
-------------------
* fix serialization on ARM

0.3.12 (2013-01-13)
-------------------

0.3.11 (2012-12-21)
-------------------
* first public release for Groovy
