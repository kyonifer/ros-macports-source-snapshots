.. rosdoc_lite documentation master file, created by
   sphinx-quickstart on Thu Oct 18 15:26:46 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

rosdoc_lite
=======================================
**rosdoc_lite** is used to generate Doxygen, Epydoc, or Sphinx documentation on a ROS package.

For detailed documentation of rosdoc_lite and its use, please see `rosdoc_lite Documentation <http://www.ros.org/wiki/rosdoc_lite>`_. 

The code API of rosdoc_lite should **not** be used as it is an internal library that is frequently changed.


