^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rosmake
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.10.7 (2013-10-04)
-------------------

1.10.6 (2013-08-22)
-------------------

1.10.5 (2013-08-21)
-------------------

1.10.4 (2013-07-05)
-------------------

1.10.3 (2013-07-03)
-------------------
* check for CATKIN_ENABLE_TESTING to enable configure without tests

1.10.2 (2013-06-18)
-------------------

1.10.1 (2013-06-06)
-------------------

1.10.0 (2013-03-22 09:23)
-------------------------

1.9 (Groovy)
============

1.9.44 (2013-03-13)
-------------------

1.9.43 (2013-03-08)
-------------------
* use -jN -lN in rosmake (`#4 <https://github.com/ros/ros/issues/4>`_)
* fix inconsistent format for ROS_PARALLEL_JOBS (`#4 <https://github.com/ros/ros/issues/4>`_)

1.9.42 (2013-01-25)
-------------------

1.9.41 (2013-01-24)
-------------------
* fix rosmake for non-empty stacks (`#4068 <https://code.ros.org/trac/ros/ticket/4068>`_)

1.9.40 (2013-01-13)
-------------------
* update rosmake to output more specific compiler warnings (`#1903 <https://code.ros.org/trac/ros/ticket/1903>`_)

1.9.39 (2012-12-30)
-------------------
* first public release for Groovy
