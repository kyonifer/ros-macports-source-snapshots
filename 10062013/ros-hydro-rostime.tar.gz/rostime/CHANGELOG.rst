^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rostime
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.16 (2013-07-14)
-------------------
* support for CATKIN_ENABLE_TESTING

0.3.15 (2013-06-06)
-------------------
* fix install destination for dll's under Windows

0.3.14 (2013-03-21)
-------------------

0.3.13 (2013-03-08)
-------------------

0.3.12 (2013-01-13)
-------------------
* improve string output of negative durations (`#3309 <https://github.com/ros/roscpp_core/issues/3309>`_)

0.3.11 (2012-12-21)
-------------------
* first public release for Groovy
