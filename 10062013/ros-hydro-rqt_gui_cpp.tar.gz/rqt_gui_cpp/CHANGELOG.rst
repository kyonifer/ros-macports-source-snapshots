^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rqt_gui_cpp
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.11 (2013-09-06)
-------------------
* fix wait for master for cpp plugins (`ros-visualization/rqt_common_plugins#173 <https://github.com/ros-visualization/rqt_common_plugins/issues/173>`_)
* detect master with background thread (`ros-visualization/rqt_common_plugins#169 <https://github.com/ros-visualization/rqt_common_plugins/issues/169>`_)

0.2.10 (2013-08-21)
-------------------
* check for master before loading a plugin and ask the user if not found (`#67 <https://github.com/ros-visualization/rqt/issues/67>`_)

0.2.9 (2013-06-06)
------------------

0.2.8 (2013-01-11)
------------------

0.2.7 (2012-12-31)
------------------
* first public release for Groovy
