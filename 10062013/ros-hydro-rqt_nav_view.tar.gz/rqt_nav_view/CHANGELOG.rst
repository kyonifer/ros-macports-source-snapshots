^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rqt_nav_view
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.0 (2013-08-28)
------------------

0.2.16 (2013-07-09)
-------------------
* First public release for Hydro @130s

0.2.15 (2013-04-25)
-------------------

0.2.14 (2013-04-12)
-------------------

0.2.13 (2013-04-09)
-------------------

0.2.12 (2013-04-06 18:22)
-------------------------

0.2.11 (2013-04-06 18:00)
-------------------------

0.2.10 (2013-04-04)
-------------------

0.2.9 (2013-03-07)
------------------
* Ensured that nav_view_dash_widget removes the widget when clicked a second time

0.2.8 (2013-01-11)
------------------
* Fix

  * Map scrolling fixed.
  * Drag and drop works everywhere now.
  * Fix map colors.

* Enhancement

  * NavFn should be the default.
  * Goals can now be set.
  * Initial pose can now be set.
  * Don't update without map.
  * Don't regenerate unless map changes.
  * Only use one transform listener.
  * Topics can be drag and dropped.

0.2.7 (2012-12-23 15:58)
------------------------
* First public release for Groovy
