nav_view
=============

RQT plugin to display navigation information(maps/plans). 
