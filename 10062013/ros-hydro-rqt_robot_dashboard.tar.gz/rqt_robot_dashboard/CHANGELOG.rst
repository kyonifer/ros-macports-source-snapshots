^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rqt_robot_dashboard
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.0 (2013-08-28)
------------------
* fix issues with battery widget (`#40 <https://github.com/ros-visualization/rqt_robot_plugins/issues/40>`_, `#42 <https://github.com/ros-visualization/rqt_robot_plugins/issues/42>`_)

0.2.16 (2013-07-09)
-------------------
* First public release for Hydro

0.2.15 (2013-04-25)
-------------------
* Fix; float values are rounded undesirably (`#21 <https://github.com/ros-visualization/rqt_robot_plugins/pull/21>`_) @dornhege @130s

0.2.14 (2013-04-12)
-------------------

0.2.13 (2013-04-09)
-------------------

0.2.12 (2013-04-06 18:22)
-------------------------

0.2.11 (2013-04-06 18:00)
-------------------------

0.2.10 (2013-04-04)
-------------------

0.2.9 (2013-03-07)
------------------

0.2.8 (2013-01-11)
------------------

0.2.7 (2012-12-23 15:58)
------------------------
* first public release for Groovy
