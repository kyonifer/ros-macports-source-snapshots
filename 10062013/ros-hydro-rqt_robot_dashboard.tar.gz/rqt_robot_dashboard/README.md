robot_dashboard
===============

Framework for creating ROS dashboards in RQT