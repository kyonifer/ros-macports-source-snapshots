=======
Widgets
=======

.. automodule:: rqt_robot_dashboard.widgets
    :members:

:class:`IconToolButton`
+++++++++++++++++++++++

.. autoclass:: rqt_robot_dashboard.widgets.IconToolButton
    :members:

:class:`MenuDashWidget`
+++++++++++++++++++++++

.. autoclass:: rqt_robot_dashboard.widgets.MenuDashWidget
    :members:

:class:`BatteryDashWidget`
++++++++++++++++++++++++++

.. autoclass:: rqt_robot_dashboard.widgets.BatteryDashWidget
    :members:

:class:`MonitorDashWidget`
++++++++++++++++++++++++++

.. autoclass:: rqt_robot_dashboard.widgets.MonitorDashWidget
    :members:

:class:`ConsoleDashWidget`
++++++++++++++++++++++++++

.. autoclass:: rqt_robot_dashboard.widgets.ConsoleDashWidget
    :members:
