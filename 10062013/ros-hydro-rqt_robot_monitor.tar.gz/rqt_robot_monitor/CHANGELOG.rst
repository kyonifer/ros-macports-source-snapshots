^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rqt_robot_monitor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.0 (2013-08-28)
------------------
* fix indication when not receiving deagnostic data (`#35 <https://github.com/ros-visualization/rqt_robot_plugins/issues/35>`_)
* fix scrolling of inspection window on new data (`#34 <https://github.com/ros-visualization/rqt_robot_plugins/issues/34>`_)

0.2.16 (2013-07-09)
-------------------
* First public release into Hydro

0.2.15 (2013-04-25)
-------------------

0.2.14 (2013-04-12)
-------------------

0.2.13 (2013-04-09)
-------------------

0.2.12 (2013-04-06 18:22)
-------------------------

0.2.11 (2013-04-06 18:00)
-------------------------

0.2.10 (2013-04-04)
-------------------

0.2.9 (2013-03-07)
------------------
* Fix

  * now run with pyside (it used to be not working with it w/o having been noticed).
  * Call .ui file in .ui is now successfully working

* Refactoring

  * Now TimelinePane uses .ui file

0.2.8 (2013-01-11)
------------------

0.2.7 (2012-12-23 15:58)
------------------------
* first public release into Groovy
