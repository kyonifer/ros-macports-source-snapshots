^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rqt_robot_plugins
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.0 (2013-08-28)
------------------

0.2.16 (2013-07-09)
-------------------
* First public release into Hydro
* add stress on how to run rqt the easiest

0.2.15 (2013-04-25)
-------------------

0.2.14 (2013-04-12)
-------------------
* Adding back rqt_tf_tree (`#19 <https://github.com/130s/rqt_robot_plugins/issues/19>`_), now that rqt_tf_tree is verified to be building on buildfarm (eg. `link http://jenkins.willowgarage.com:8080/view/GbinP64/job/ros-groovy-rqt-tf-tree_binarydeb_precise_amd64/`_)

0.2.13 (2013-04-09)
-------------------
* Conform to REP-127
* Add rqt_moveit

0.2.12 (2013-04-06 18:22)
-------------------------
* Add CMakeLists.txt based on new catkin spec (`ref. http://answers.ros.org/question/59648/catkin-metapackage-now-requires-cmakeliststxt/`_)

0.2.11 (2013-04-06 18:00)
-------------------------
* Revert back rqt_tf_tree that's been omitted due to build failure

0.2.10 (2013-04-04)
-------------------

0.2.9 (2013-03-07)
------------------

0.2.8 (2013-01-11)
------------------

0.2.7 (2012-12-23 15:58)
------------------------
* Revert back rviz plugin (since 0.2.6) @dirk-thomas

0.2.6 (2012-12-23 01:57)
------------------------
* first public release for Groovy
