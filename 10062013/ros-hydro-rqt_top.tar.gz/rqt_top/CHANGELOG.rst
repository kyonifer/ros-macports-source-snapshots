^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rqt_top
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.0 (2013-08-28)
------------------
* remove copy of psutil module and implement missing function (`#105 <https://github.com/ros-visualization/rqt_common_plugins/issues/105>`_)

0.2.17 (2013-07-06)
-------------------
* Embeds python-psutil in the package in order to be enabled on Ubuntu Precise
* first release of this package into hydro

