^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package smach_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.3.1 (2013-07-22)
------------------
* adding changelogs
* Updating maintainer name

* Updating maintainer name
