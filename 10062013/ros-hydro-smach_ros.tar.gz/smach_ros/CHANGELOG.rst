^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package smach_ros
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.3.1 (2013-07-22)
------------------
* adding changelogs
* added missing catkin_package() calls in CMakeLists.txt files of packages smach and smach_ros
* Updating maintainer name

* added missing catkin_package() calls in CMakeLists.txt files of packages smach and smach_ros
* Updating maintainer name
