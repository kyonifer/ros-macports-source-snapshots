The URDF (U-Robot Description Format) headers
  provides core data structure headers for URDF.

For now, the details of the URDF specifications reside on
  http://ros.org/wiki/urdf

